// Program.cs  � DocuSign -> IIS listener -> CRM on-prem (NTLM/AD over internal IP)
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;

var builder = WebApplication.CreateBuilder(args);

// ---------- Config via IIS environment variables ----------
// DocuSign
string dsSecretB64 = Env("DS_CONNECT_SECRET_B64");                  // Connect Key (Base64)  <-- required
bool ackFast = Env("ACK_FAST", "true").Equals("true", StringComparison.OrdinalIgnoreCase);
// Optional basic auth for the webhook itself
string basicUser = Env("BASIC_AUTH_USER");
string basicPass = Env("BASIC_AUTH_PASS");

// CRM (internal NTLM/AD)
string crmUrl = Env("CRM_INTERNAL_URL", "http://10.141.0.170/CrmUat"); // INTERNAL org URL (with org name)
string crmAuthType = Env("CRM_AUTH_TYPE", "AD");                              // AD (Windows/NTLM)
string crmDomain = Env("CRM_DOMAIN", "netwaysdev");
string crmUser = Env("CRM_USERNAME", "mhmoussa@Netwaysdev.local");                        // can be 'mhmoussa' or UPN
string crmPass = Env("CRM_PASSWORD","MhM@123456");                                    // set in IIS
string customApi = Env("CRM_CUSTOM_API", "ntw_DocuSign_Ingress");          // your Custom API logical name

// Allow larger payloads
builder.WebHost.UseKestrel(o => o.Limits.MaxRequestBodySize = 50 * 1024 * 1024);

var app = builder.Build();

app.MapGet("/", () => Results.Ok("Listener is running"));
app.MapGet("/healthz", () => Results.Ok("ok"));

app.MapPost("/docusign/webhook", async (HttpContext ctx) =>
{
    // (0) Optional Basic auth for the webhook itself
    if (!string.IsNullOrEmpty(basicUser) || !string.IsNullOrEmpty(basicPass))
    {
        if (!IsBasicAuthValid(ctx.Request.Headers.Authorization, basicUser, basicPass))
            return Results.Unauthorized();
    }

    // (1) Read RAW body
    ctx.Request.EnableBuffering();
    using var ms = new MemoryStream();
    await ctx.Request.Body.CopyToAsync(ms);
    var raw = ms.ToArray();
    ctx.Request.Body.Position = 0;

    // (2) Verify DocuSign HMAC
    var sigHeader = ctx.Request.Headers["X-DocuSign-Signature-1"].ToString();
    if (string.IsNullOrWhiteSpace(sigHeader) || string.IsNullOrWhiteSpace(dsSecretB64))
        return Results.Unauthorized();
    if (!VerifyHmac(dsSecretB64, raw, sigHeader))
        return Results.Unauthorized();

    // (3) Process
    if (ackFast)
    {
        _ = Task.Run(() => ProcessAsync(raw, BuildAdConnString(crmUrl, crmDomain, crmUser, crmPass), customApi));
        return Results.Ok();
    }

    await ProcessAsync(raw, BuildAdConnString(crmUrl, crmDomain, crmUser, crmPass), customApi);
    return Results.Ok();
});

app.Run();

// ---------------- helpers ----------------
static string Env(string name, string? fallback = null)
{
    var v = Environment.GetEnvironmentVariable(name);
    if (!string.IsNullOrEmpty(v)) return v;
    return fallback ?? "";
}

static bool IsBasicAuthValid(string? authHeader, string expectedUser, string expectedPass)
{
    if (string.IsNullOrEmpty(expectedUser) && string.IsNullOrEmpty(expectedPass)) return true;
    if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        return false;

    try
    {
        var b64 = authHeader.Substring("Basic ".Length).Trim();
        var up = Encoding.UTF8.GetString(Convert.FromBase64String(b64));
        var i = up.IndexOf(':');
        if (i < 0) return false;
        var u = up[..i]; var p = up[(i + 1)..];
        return u == expectedUser && p == expectedPass;
    }
    catch { return false; }
}

static bool VerifyHmac(string secretB64, byte[] payload, string sigHeaderB64)
{
    try
    {
        var secret = Convert.FromBase64String(secretB64);
        using var hmac = new HMACSHA256(secret);
        var calcB64 = Convert.ToBase64String(hmac.ComputeHash(payload));
        return CryptographicOperations.FixedTimeEquals(
            Encoding.ASCII.GetBytes(calcB64),
            Encoding.ASCII.GetBytes(sigHeaderB64));
    }
    catch { return false; }
}

static string BuildAdConnString(string url, string domain, string user, string pass)
{
    // Works with internal Windows/NTLM endpoint (not IFD). URL MUST include org name.
    // Username can be DOMAIN\user OR UPN (user@domain.local). We'll pass DOMAIN\user here.
    var userFmt = user.Contains('\\') || user.Contains('@') ? user : $"{domain}\\{user}";
    return $@"
AuthType=AD;
Url={url};
Domain={domain};
Username={userFmt};
Password={pass};
";
}

static async Task ProcessAsync(byte[] raw, string connStr, string customApiName)
{
    var body = Encoding.UTF8.GetString(raw);

    // If you need to parse JSON for extra inputs:
    // using var doc = JsonDocument.Parse(raw);
    // var envelopeId = doc.RootElement.GetProperty("envelopeId").GetString();

    try
    {
        using var client = new CrmServiceClient(connStr);
        if (!client.IsReady) throw new Exception(client.LastCrmError);

        var req = new OrganizationRequest(customApiName);
        req["RequestBody"] = body;   // match your Custom API input name/type
        // req["EnvelopeId"] = envelopeId;  // add if your Custom API defines it
        client.Execute(req);
    }
    catch (Exception ex)
    {
        // TODO: add real logging
        Console.Error.WriteLine($"CRM call failed: {ex.Message}");
        throw;
    }

    await Task.CompletedTask;
}
